package week4

import week3._
/**
  * Created by ji.dai on 11/7/16.
  */
class TestSubtyping {
  val a : Array[NonEmpty] = Array(new NonEmpty(1, Empty, Empty))
  //val b : Array[IntSet] = a
}
