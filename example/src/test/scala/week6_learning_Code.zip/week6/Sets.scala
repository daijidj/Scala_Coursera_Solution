package week6

/**
  * Created by ji.dai on 11/18/16.
  */
object Sets {
  def main (args : Array[String]) : Unit = {
    val fruit = Set("Apple", "Banana" , "Pear")
    val s = (1 to 6).toSet
  }

}
